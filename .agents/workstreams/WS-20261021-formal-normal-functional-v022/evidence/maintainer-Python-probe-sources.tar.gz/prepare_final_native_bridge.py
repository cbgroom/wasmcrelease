import json,hashlib,subprocess,sys,tarfile,tempfile
from pathlib import Path
root=Path.cwd();commit=sys.argv[1];assert len(commit)==40 and all(x in '0123456789abcdef' for x in commit)
git=lambda *args:subprocess.check_output(['git',*args])
assert git('status','--porcelain').strip()==b''
assert git('rev-parse','HEAD').decode().strip()==commit
tree=git('rev-parse',commit+'^{tree}').decode().strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
own=root/'.agents/workstreams/WS-20261021-formal-normal-functional-v022'
prior=json.loads((own/'evidence/native-input-custody-v022.json').read_text())
actual='7fbdb6a450354dda20c9077a403b503db0ca7f1f';assert prior['actual_build_source']==actual and prior['inputs']==27
rows=prior['exact_unchanged_build_package_qualification_inputs'];assert len(rows)==27
for row in rows:
 before=git('show',actual+':'+row['path']);after=git('show',commit+':'+row['path'])
 assert before==after and len(after)==row['bytes'] and sha(after)==row['sha256'],row['path']
assets=root/'target/release-v022-assets';prepared=json.loads((assets/'native-assets-receipt.json').read_text());assert len(prepared['assets'])==6
for asset in prepared['assets']:
 p=assets/asset['name'];assert len(p.read_bytes())==asset['bytes'] and sha(p.read_bytes())==asset['sha256']
 with tempfile.TemporaryDirectory(prefix='wasmc-v022-native-reopen-') as tmp:
  with tarfile.open(p) as t:
   for m in t.getmembers():assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not m.issym() and not m.islnk()
   t.extractall(tmp,filter='data')
  manifests=list(Path(tmp).glob('**/manifest.json'));assert len(manifests)==1
  package=manifests[0].parent;assert sha(manifests[0].read_bytes())==asset['package_manifest_sha256']
  subprocess.run(['node','scripts/native-package.mjs','verify',str(package),asset['target'],actual],check=True)
receipt={'schema':'wasmc.native-final-input-custody-bridge/v1','release_version':'0.0.22','final_release_commit':commit,'final_release_tree':tree,
 'actual_build_source':actual,'actual_run':39560999862,'actual_six_builds_and_six_matching_downloaded_consumers':'success',
 'compiler_sha256':prepared['compiler_sha256'],'exact_unchanged_inputs':rows,'input_count':27,'original_custody_receipt_sha256':sha((own/'evidence/native-input-custody-v022.json').read_bytes()),
 'six_archives_reopened':True,'assets':prepared['assets'],'compiler_Lib_Native_rebuilds':0,
 'scope':'Input equality and independent exact archive reopen; actual build and final commit are distinct. Publication and public downloads require separate observation.'}
out=assets/'Native-final-input-custody-bridge.json';assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'accepted':True,'actual_build_source':actual,'final_commit':commit,'input_count':27,'archives':6,'receipt_sha256':sha(out.read_bytes())}))
